def build_inbound_rows(inbounds):
    """Build rows for inbounds table."""
    rows = []
    for ib in inbounds:
        protocol = ib.get("protocol", "")
        tag = ib.get("tag", "")
        port = ib.get("port", "")
        listen = ib.get("listen", "")
        stream = ib.get("streamSettings") or {}
        network = stream.get("network", "")
        ws = stream.get("wsSettings") or {}
        ws_path = ws.get("path", "")
        rows.append(
            {
                "tag": tag,
                "protocol": protocol,
                "listen": listen,
                "port": port,
                "network": network,
                "ws_path": ws_path,
            }
        )
    return rows


def build_outbound_rows(outbounds):
    """Build rows for outbounds table and collect outbound tags."""
    outbound_rows = []
    outbound_tags = []
    for ob in outbounds:
        tag = ob.get("tag", "")
        protocol = ob.get("protocol", "")
        settings = ob.get("settings") or {}
        addr = ""
        port = ""
        if protocol in ("socks", "trojan"):
            servers = settings.get("servers") or []
            if servers:
                s0 = servers[0]
                addr = s0.get("address", "")
                port = s0.get("port", "")
        else:
            addr = "-"
            port = "-"
        outbound_rows.append(
            {"tag": tag, "protocol": protocol, "address": addr, "port": port}
        )
        if tag and tag not in outbound_tags:
            outbound_tags.append(tag)
    return outbound_rows, outbound_tags


def extract_inbound_auth(inbound):
    """Extract auth info from inbound.

    - vmess/vless: uuid (clients[0].id)
    - trojan: password (clients[0].password)
    Returns empty string if not found.
    """
    proto = (inbound.get("protocol") or "").lower()
    settings = inbound.get("settings") or {}
    clients = settings.get("clients") or []
    if not isinstance(clients, list) or not clients:
        return ""
    c0 = clients[0]
    if not isinstance(c0, dict):
        return ""
    if proto in ("vmess", "vless"):
        return c0.get("id", "") or ""
    if proto == "trojan":
        return c0.get("password", "") or ""
    return ""
