from flask import Flask, render_template, request, redirect, session
from functools import wraps
import os
import subprocess
import shlex

from v2panel_core import handle_post_action, build_panel_context

app = Flask(__name__)

# ===== 登录配置（可以用环境变量覆盖）=====
#   export V2PANEL_USER='youruser'
#   export V2PANEL_PASS='yourpass'
USERNAME = os.getenv("V2PANEL_USER", "admin")
PASSWORD = os.getenv("V2PANEL_PASS", "change_me_please")

# Flask session 密钥（强烈建议改成随机字符串或用环境变量）
app.secret_key = os.getenv(
    "V2PANEL_SECRET",
    "please-change-this-secret-123456"
)

# ===== 面板外部访问前缀 =====
# 默认使用根路径访问：
#   http://IP:9000/
#   https://panel.example.com/
# 如果你真的想挂在子路径（例如 /panel），可以：
#   export V2PANEL_PREFIX="/panel"
PANEL_PREFIX = os.getenv("V2PANEL_PREFIX", "").strip()
if PANEL_PREFIX in ("", "/"):
    PANEL_PREFIX = ""
else:
    if not PANEL_PREFIX.startswith("/"):
        PANEL_PREFIX = "/" + PANEL_PREFIX
    PANEL_PREFIX = PANEL_PREFIX.rstrip("/")

# 一键安装 V2Ray 的在线脚本 URL
# 你给的地址：https://raw.githubusercontent.com/networkdu/ray/refs/heads/main/install.sh
INSTALL_URL = os.getenv(
    "V2PANEL_INSTALL_URL",
    "https://raw.githubusercontent.com/networkdu/ray/refs/heads/main/install.sh",
)


def external_path(path: str) -> str:
    """
    把后端的 /login / 这样的路径，转换成“外部路径”：
    默认（无前缀）：
        /login -> /login
        /      -> /
    配置了 V2PANEL_PREFIX=/panel 时：
        /login -> /panel/login
        /      -> /panel/
    （这里仅负责“对外 URL 长什么样”，具体有没有反代由你自己 Nginx 决定）
    """
    if not path.startswith("/"):
        path = "/" + path
    prefix = PANEL_PREFIX or ""
    if prefix:
        if path == "/":
            return prefix + "/"
        return prefix + path
    return path


def login_required(f):
    """简单登录保护装饰器"""
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("logged_in"):
            # next 用“外部路径”（可能带前缀，也可能是根路径）
            next_url = external_path(request.path)
            login_url = external_path("/login")
            return redirect(f"{login_url}?next={next_url}")
        return f(*args, **kwargs)
    return wrapper


@app.route("/login", methods=["GET", "POST"])
def login():
    # 已登录直接回首页
    if session.get("logged_in"):
        return redirect(external_path("/"))

    error = None
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = (request.form.get("password") or "").strip()

        if username == USERNAME and password == PASSWORD:
            session["logged_in"] = True
            next_url = request.args.get("next")
            if next_url:
                return redirect(next_url)
            return redirect(external_path("/"))
        else:
            error = "Invalid username or password."

    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(external_path("/login"))


@app.route("/", methods=["GET", "POST"])
@login_required
def index():
    message = None
    created_info = None
    edited_info = None

    if request.method == "POST":
        # 重启 / 新增入站 / 编辑入站 / 更新路由 都在这里处理
        message, created_info, edited_info = handle_post_action(request.form)

    # 构建渲染模板需要的数据
    context = build_panel_context(
        message=message,
        created_info=created_info,
        edited_info=edited_info,
        panel_prefix=PANEL_PREFIX or "",
        install_output=None,  # 默认没有安装输出
    )
    return render_template("index.html", **context)


@app.route("/install_v2ray", methods=["POST"])
@login_required
def install_v2ray():
    """
    一键运行线上 V2Ray 安装脚本，并在页面展示脚本输出。

    注意：脚本里有 apt / yum / systemctl 等操作，
    运行 v2panel 的这个 Python 进程本身必须有相应权限（通常你用 root 跑）。
    """
    install_output = ""
    success = False

    # 直接在线拉取脚本并交给 bash 执行
    cmd = f"curl -fsSL {shlex.quote(INSTALL_URL)} | bash"

    try:
        completed = subprocess.run(
            ["bash", "-c", cmd],
            capture_output=True,
            text=True,
            timeout=3600,  # 最长 60 分钟，避免死挂
        )
        success = (completed.returncode == 0)
        install_output = (
            f"脚本来源: {INSTALL_URL}\n"
            f"脚本退出码: {completed.returncode}\n\n"
            f"===== STDOUT =====\n{completed.stdout}\n\n"
            f"===== STDERR =====\n{completed.stderr}"
        )
    except Exception as e:
        install_output = f"执行安装脚本时出错: {e!r}"

    if success:
        message = "✅ 已执行 V2Ray 在线安装脚本，若无报错则已安装完成。"
    else:
        message = "⚠️ 在线安装脚本执行完成，但可能存在错误，请检查输出。"

    # 执行完后重新构建面板上下文（可能已经生成 config.json 了）
    context = build_panel_context(
        message=message,
        created_info=None,
        edited_info=None,
        panel_prefix=PANEL_PREFIX or "",
        install_output=install_output,
    )
    return render_template("index.html", **context)


if __name__ == "__main__":
    # 监听所有地址，方便 Nginx 反代或直接用 IP 访问
    app.run(host="0.0.0.0", port=9000, debug=False)

