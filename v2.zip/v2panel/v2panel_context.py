from v2panel_config import load_config, ensure_inbound_tags
from v2panel_routing import parse_simple_routing
from v2panel_inbounds import (
    build_inbound_rows,
    build_outbound_rows,
    extract_inbound_auth,
)


def build_panel_context(
    message=None,
    created_info=None,
    edited_info=None,
    panel_prefix="",
):
    """Build the template context for the main panel page."""
    cfg = load_config()
    inbounds, inbound_tag_to_proto = ensure_inbound_tags(cfg)
    routing, editable_route_map, _ = parse_simple_routing(cfg)
    outbounds = cfg.get("outbounds", []) or []

    inbound_rows = build_inbound_rows(inbounds)
    outbound_rows, outbound_tags = build_outbound_rows(outbounds)
    inbound_tags_all = sorted(inbound_tag_to_proto.keys())

    # Defaults for "Edit inbound" form: listen / port / ws path / auth
    edit_inbound_defaults = {}
    for ib in inbounds:
        tag = ib.get("tag")
        if not tag:
            continue
        listen = ib.get("listen", "")
        port = ib.get("port", "")
        stream = ib.get("streamSettings") or {}
        ws = stream.get("wsSettings") or {}
        ws_path = ws.get("path", "")
        auth = extract_inbound_auth(ib)
        edit_inbound_defaults[tag] = {
            "listen": listen,
            "port": str(port) if port is not None else "",
            "ws_path": ws_path,
            "auth": auth,
        }

    return {
        "inbound_rows": inbound_rows,
        "outbound_rows": outbound_rows,
        "inbound_tags_all": inbound_tags_all,
        "outbound_tags": outbound_tags,
        "editable_route_map": editable_route_map,
        "inbound_proto_map": inbound_tag_to_proto,
        "edit_inbound_defaults": edit_inbound_defaults,
        "message": message,
        "created_info": created_info,
        "edited_info": edited_info,
        "panel_prefix": panel_prefix,
    }
