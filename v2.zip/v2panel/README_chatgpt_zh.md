# README_chatgpt_zh.md
> 给下一次接手这个仓库的 ChatGPT 看的说明书（拆分版 + 编辑表单自动带原值）

请先 **完整读完本文件**，再动代码。  
目标是：在“**小而稳**”的前提下帮用户改功能，而不是大重构。

---

## 1. 这是个什么项目？

- 一个极简的 **V2Ray 配置管理面板**。
- 技术栈：**Flask（后端） + 纯 HTML/CSS/少量原生 JS（前端）**。
- 面板只做一件事：**安全地修改 `/usr/local/bin/v2ray/config.json`**。

已实现的主要能力：

1. 展示当前配置中的：
   - inbounds 列表（tag / 协议 / 监听地址 / 端口 / ws path 等）；
   - outbounds 列表（tag / 协议 / 地址 / 端口）。
2. 管理一类「简单路由」：  
   只包含 `inboundTag / inboundTags + outboundTag` 的 `type=field` 规则。
3. 新增入站（inbound）：
   - 支持 `vmess / vless / trojan`，全部走 WebSocket (`network = "ws"`)。
4. 编辑已有入站：
   - 可改 listen / port / ws path / 认证信息（UUID 或密码）；
   - **编辑表单会自动带上原有值（已实现，别弄丢）。**
5. 一键重启 v2ray：
   - 调用 `systemctl restart v2ray`。

---

## 2. 当前代码结构（已经拆成多个模块）

仓库大致结构：

- `app.py` – Flask 入口 & Web 层
- `v2panel_core.py` – 极薄“门面”，只导出两个入口函数
- `v2panel_config.py` – 配置文件读写 + 补全 inbound tag
- `v2panel_routing.py` – 简单路由解析（inboundTag → outboundTag）
- `v2panel_inbounds.py` – inbounds/outbounds 展示数据 + 认证信息提取
- `v2panel_actions.py` – 处理所有 POST 表单动作（写配置）
- `v2panel_context.py` – 构造模板上下文（包含编辑表单默认值）
- `templates/`
  - `index.html` – 主面板页面（含「编辑入站表单自动预填」的 JS）
  - `login.html` – 登录页
- `README_chatgpt_zh.md` / `README_chatgpt_en.md` – 本说明书的中英文版

### 2.1 `app.py`（不要破坏接口）

- 负责：
  - 登录 / 登出；
  - URL 前缀：`PANEL_PREFIX`（例如 `/panel`）；
  - 路由：`/login`、`/`、`/index`。
- 通过：

  ```python
  from v2panel_core import handle_post_action, build_panel_context
  ```

  使用面板逻辑：

  - GET：`build_panel_context(...)` → 渲染 `index.html`；
  - POST：`handle_post_action(request.form)` → 修改配置，再重建 context。

> **不要改这两个函数的名字和返回结构**，除非你同步修改 `app.py`。

### 2.2 `v2panel_core.py`（薄门面）

```python
from v2panel_actions import handle_post_action
from v2panel_context import build_panel_context

__all__ = ["handle_post_action", "build_panel_context"]
```

- 不做业务，只负责把调用转发到拆分后的模块。
- 未来新功能也应通过新增模块 + 在这里统一导出，保持 `app.py` 不用改。

### 2.3 `v2panel_config.py`

职责：

- `CONFIG_PATH = Path("/usr/local/bin/v2ray/config.json")`（不要乱改）。
- `load_config()`：使用 `json5` 读取支持注释的配置。
- `save_config(cfg)`：
  - 写入前先备份：`config.json.bak`；
  - 再写新的 JSON（无注释）。
- `ensure_inbound_tags(cfg)`：
  - 确保每个 inbound 都有 `tag`：
    - 有 `port`：`"{protocol}-{port}"`；
    - 没 `port`：`"{protocol}-auto-{index}"`。
  - 返回 `(inbounds, inbound_tag_to_proto)`。

> **所有对 config.json 的写操作必须走 `save_config`。**

### 2.4 `v2panel_routing.py`

- `parse_simple_routing(cfg)`：
  - 从 `cfg["routing"]["rules"]` 中拆出：
    - `editable_route_map`：只包含
      - `type = "field"`；
      - 仅 `inboundTag(s)` + `outboundTag` 的简单规则；
    - `non_editable_rules`：其它复杂规则全部原样保留。
  - 返回 `(routing_obj, editable_route_map, non_editable_rules)`。

> 今后扩展路由相关功能时，请继续沿用“简单可编辑 + 复杂原样保留”的设计。

### 2.5 `v2panel_inbounds.py`

- `build_inbound_rows(inbounds)`：
  - 生成入站表格行：`tag / protocol / listen / port / network / ws_path`。
- `build_outbound_rows(outbounds)`：
  - 生成出站表格行 + `outbound_tags` 列表。
- `extract_inbound_auth(inbound)`：
  - 用于读取“认证信息”：
    - vmess/vless：`settings.clients[0].id`；
    - trojan：`settings.clients[0].password`。
  - 取不到则返回空串。

> 编辑表单的默认“认证信息”就是通过它拿到的。  
> 如果未来改了 config 结构，记得同步更新这里。

### 2.6 `v2panel_actions.py`

- 负责所有写操作：
  - `restart_v2ray()`：`systemctl restart v2ray` 并返回结果文案。
  - `handle_post_action(form)`：统一处理所有 POST：
    - `restart`：调用 `restart_v2ray()`；
    - `update_routes`：更新“简单路由”；
    - `add_inbound`：新增 vmess/vless/trojan ws 入站；
    - `edit_inbound`：编辑入站基础字段 + 可选更新认证。

写入配置时统一走 `save_config(cfg)`，并保留 `.bak` 备份。  
新增入站时会自动：

- listen 默认 `127.0.0.1`；
- tag 默认 `"{protocol}-{port}"`；
- ws_path 默认 `"/" + tag`；
- auth：
  - vmess/vless：自动生成 UUID；
  - trojan：自动生成随机密码。

### 2.7 `v2panel_context.py`

- `build_panel_context(...)`：
  - 读取最新 config；
  - 调用：
    - `ensure_inbound_tags` / `parse_simple_routing`；
    - `build_inbound_rows` / `build_outbound_rows`；
    - `extract_inbound_auth`。

构造模板变量：

- `inbound_rows` / `outbound_rows`；
- `inbound_tags_all` / `outbound_tags`；
- `editable_route_map` / `inbound_proto_map`；
- **`edit_inbound_defaults`**：编辑表单的默认值字典；
- `message` / `created_info` / `edited_info` / `panel_prefix`。

`edit_inbound_defaults` 结构：

```python
{
  "<tag>": {
    "listen": "...",
    "port": "..." ,  # 字符串
    "ws_path": "...",
    "auth": "...",   # UUID 或密码
  },
  ...
}
```

模板会把它序列化成 JS 变量，用于自动填充「编辑入站」表单。

---

## 3. 编辑入站时表单自动带上原有值（已实现）

**这是用户明确需求，已经实现，后续改动一定不要无意删掉。**

### 3.1 后端：`edit_inbound_defaults`

在 `v2panel_context.build_panel_context` 中：

- 遍历所有 inbounds；
- 对每个 tag 收集：
  - `listen`：`ib["listen"]`；
  - `port`：`ib["port"]` 转成字符串；
  - `ws_path`：`ib["streamSettings"]["wsSettings"]["path"]`；
  - `auth`：通过 `extract_inbound_auth(ib)` 获取 UUID/密码；
- 组合为 `edit_inbound_defaults[tag] = {...}`；
- 传入模板。

### 3.2 前端：`templates/index.html` 中的 JS

在 `</body>` 之前有一段 JS：

```html
<script>
    const V2PANEL_EDIT_INBOUND_DEFAULTS = {{ edit_inbound_defaults | tojson | safe }};

    function v2panelFillEditInboundForm() {
        var select = document.querySelector('select[name="edit_tag"]');
        if (!select) return;
        var data = V2PANEL_EDIT_INBOUND_DEFAULTS[select.value] || {};

        var listenInput = document.querySelector('input[name="edit_listen"]');
        var portInput = document.querySelector('input[name="edit_port"]');
        var wsInput = document.querySelector('input[name="edit_ws_path"]');
        var authInput = document.querySelector('input[name="edit_auth"]');

        if (listenInput) listenInput.value = data.listen || "";
        if (portInput) portInput.value = data.port || "";
        if (wsInput) wsInput.value = data.ws_path || "";
        if (authInput) authInput.value = data.auth || "";
    }

    document.addEventListener('DOMContentLoaded', function () {
        var select = document.querySelector('select[name="edit_tag"]');
        if (!select) return;
        select.addEventListener('change', v2panelFillEditInboundForm);
        v2panelFillEditInboundForm(); // 页面加载后自动填一次
    });
</script>
```

行为：

- 页面加载后：
  - 默认选中的第一个 tag 会把当前配置的值填进输入框；
- 用户切换下拉框：
  - 会根据新的 tag 自动刷新 4 个输入框。

> 之后如要修改字段名或表单结构，记得同步更新：
>
> - `v2panel_context.build_panel_context` 中构造 `edit_inbound_defaults` 的逻辑；
> - 这段 JS 中读写到的字段名。

---

## 4. 登录 & 安全假设

- 单用户后台，密码来自环境变量：
  - `V2PANEL_USER` / `V2PANEL_PASS`。
- Flask `secret_key` 来自 `V2PANEL_SECRET`（默认值很弱，部署时务必修改）。
- 面板通常部署在：
  - 内网；或
  - Nginx 之后，再加一层 Basic Auth / IP 白名单等。

当前无 CSRF 防护。  
如需新增，优先在 `app.py` 层用统一机制处理，不要在各个模块里东打一榔头西打一榔头。

> 除非用户明确要求，否则不要设计新的登录逻辑，更不要把密码写进 config.json。

---

## 5. 写操作约束（务必遵守）

1. 所有对 config.json 的写入必须：
   - 使用 `save_config(cfg)`；
   - 保留「写前备份为 `config.json.bak`」的行为。

2. 路由管理边界：
   - 面板只动“简单 inboundTag 路由”：
     - `type = "field"`；
     - 只含 `inboundTag(s)` + `outboundTag`。
   - 复杂规则（domain/ip/port 等）必须原样保留。

3. 重启行为：
   - 一律通过 `systemctl restart v2ray`。
   - 如要增加 `status` / 测试配置，只能在此基础上扩展，而不是替换。

4. UI 风格：
   - 深色 + 渐变 + 轻量 CSS，不要引入 React / Vue / Tailwind 等重型前端框架。
   - 可添加少量 JS 提升体验，但保持简单直观。

---

## 6. 以后可以怎么安全扩展？

举例：

- 为每个 inbound 增加「复制节点链接」按钮；
- 加一个「测试配置」按钮：调用 `v2ray -test`，展示结果；
- 在页面中增加折叠区域，展示当前完整 config.json（只读）。

无论做什么扩展，尽量做到：**增量 + 不破坏现有行为**。

---

## 7. TL;DR 给未来的你

- 入口仍是：`v2panel_core.handle_post_action` / `build_panel_context`；
- 所有写配置的地方都必须走 `save_config`，并保留 `.bak` 备份；
- 只动“简单 inboundTag 路由”，复杂规则别碰；
- 编辑入站表单已经实现“自动带上原有值”，后续改动别搞丢；
- 不要胡乱引入新依赖，保持项目小而清晰。

如果用户需求不够清楚，请先在回答中把你的改动方案讲清楚，再给代码。
