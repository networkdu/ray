def parse_simple_routing(cfg):
    """Parse simple inboundTag routing rules.

    We only manage rules with:
      - type = "field"
      - keys limited to inboundTag / inboundTags / outboundTag

    Returns: (routing_obj, editable_route_map, non_editable_rules)
    where editable_route_map is {inboundTag: outboundTag}.
    """
    routing = cfg.get("routing", {}) or {}
    rules = routing.get("rules", []) or []
    editable_route_map = {}
    non_editable_rules = []

    for r in rules:
        r_type = r.get("type")
        inbound_tags = r.get("inboundTag") or r.get("inboundTags")
        outbound_tag = r.get("outboundTag")
        keys = set(r.keys())
        simple_rule = (
            r_type == "field"
            and inbound_tags
            and outbound_tag
            and keys.issubset({"type", "inboundTag", "inboundTags", "outboundTag"})
        )
        if not simple_rule:
            non_editable_rules.append(r)
            continue

        if isinstance(inbound_tags, str):
            inbound_tags_list = [inbound_tags]
        else:
            inbound_tags_list = list(inbound_tags)

        for t in inbound_tags_list:
            if isinstance(t, str):
                editable_route_map[t] = outbound_tag

    return routing, editable_route_map, non_editable_rules
