# README_chatgpt.md

This repo includes two detailed handoff documents for ChatGPT:

- `README_chatgpt_zh.md` – Chinese version
- `README_chatgpt_en.md` – English version

Please read one of them fully before modifying the code.
