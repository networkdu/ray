import subprocess
import uuid
import secrets

from v2panel_config import load_config, save_config, ensure_inbound_tags
from v2panel_routing import parse_simple_routing


def restart_v2ray():
    """Restart v2ray service via systemctl."""
    try:
        completed = subprocess.run(
            ["systemctl", "restart", "v2ray"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if completed.returncode == 0:
            return True, "✅ 已通过 systemctl 重启 v2ray 服务。"
        else:
            msg = completed.stderr.strip() or completed.stdout.strip() or "未知错误"
            return False, f"❌ 重启 v2ray 失败：{msg}"
    except Exception as e:
        return False, f"❌ 调用 systemctl 重启 v2ray 时出错：{e}"


def handle_post_action(form):
    """Handle all POST actions.

    Supported actions:
      - restart       : restart v2ray
      - update_routes : update simple inboundTag routing
      - add_inbound   : add a new inbound
      - edit_inbound  : edit an existing inbound
    """
    cfg = load_config()
    inbounds, inbound_tag_to_proto = ensure_inbound_tags(cfg)
    routing, editable_route_map_tmp, non_editable_rules = parse_simple_routing(cfg)

    message = None
    created_info = None
    edited_info = None

    inbound_tags_all = sorted(inbound_tag_to_proto.keys())
    action = (form.get("action") or "update_routes").strip()

    # 1) restart v2ray
    if action == "restart":
        ok, msg = restart_v2ray()
        message = msg

    # 2) update routes
    elif action == "update_routes":
        new_route_map = {}
        for tag in inbound_tags_all:
            field_name = f"route_{tag}"
            val = (form.get(field_name) or "").strip()
            if val and val != "NONE":
                new_route_map[tag] = val

        new_editable_rules = []
        for tag, ob_tag in new_route_map.items():
            new_editable_rules.append(
                {"type": "field", "inboundTag": [tag], "outboundTag": ob_tag}
            )

        new_rules = new_editable_rules + non_editable_rules
        routing["rules"] = new_rules
        cfg["routing"] = routing
        cfg["inbounds"] = inbounds
        save_config(cfg)
        message = "✅ 路由已更新并写入 config.json（原文件已备份为 config.json.bak）。"

    # 3) add inbound
    elif action == "add_inbound":
        protocol = (form.get("protocol") or "").strip().lower()
        if protocol in ("trojans", "trojan"):
            protocol = "trojan"
        listen = (form.get("listen") or "").strip() or "127.0.0.1"
        port_str = (form.get("port") or "").strip()
        tag = (form.get("tag") or "").strip()
        ws_path = (form.get("ws_path") or "").strip()
        auth = (form.get("auth") or "").strip()

        errors = []
        if protocol not in ("vmess", "vless", "trojan"):
            errors.append("协议必须是 vmess / vless / trojan 之一。" )
        if not port_str:
            errors.append("端口不能为空。" )
        try:
            port = int(port_str)
        except ValueError:
            errors.append("端口必须是数字。" )
            port = None

        if not ws_path:
            base = tag or (f"{protocol}-{port_str or 'auto'}")
            ws_path = "/" + base.lstrip("/")

        if not tag:
            tag = f"{protocol}-{port_str or 'auto'}"

        if errors:
            message = " / ".join(errors)
        else:
            settings = {}
            extra_info = {}
            if protocol in ("vmess", "vless"):
                client_id = auth or str(uuid.uuid4())
                extra_info["id"] = client_id
                if protocol == "vmess":
                    settings = {"clients": [{"id": client_id, "alterId": 0}]}
                else:
                    settings = {
                        "clients": [{"id": client_id, "level": 0}],
                        "decryption": "none",
                    }
            elif protocol == "trojan":
                password = auth or secrets.token_urlsafe(12)
                extra_info["password"] = password
                settings = {"clients": [{"password": password}]}

            new_ib = {
                "port": port,
                "listen": listen,
                "protocol": protocol,
                "tag": tag,
                "settings": settings,
                "streamSettings": {
                    "network": "ws",
                    "wsSettings": {"path": ws_path},
                },
            }
            inbounds.append(new_ib)
            cfg["inbounds"] = inbounds
            save_config(cfg)
            created_info = {
                "protocol": protocol,
                "tag": tag,
                "listen": listen,
                "port": port,
                "ws_path": ws_path,
                **extra_info,
            }
            message = "✅ 已新增入站，并写入 config.json。"

    # 4) edit inbound
    elif action == "edit_inbound":
        edit_tag = (form.get("edit_tag") or "").strip()
        new_listen = (form.get("edit_listen") or "").strip()
        new_port_str = (form.get("edit_port") or "").strip()
        new_ws_path = (form.get("edit_ws_path") or "").strip()
        new_auth = (form.get("edit_auth") or "").strip()

        inbound = None
        for ib in inbounds:
            if ib.get("tag") == edit_tag:
                inbound = ib
                break

        if inbound is None:
            message = f"找不到 tag 为 {edit_tag} 的入站。"
        else:
            proto = inbound.get("protocol", "")
            if not new_listen:
                new_listen = inbound.get("listen", "127.0.0.1")

            errors = []
            try:
                if new_port_str:
                    new_port = int(new_port_str)
                else:
                    new_port = inbound.get("port")
            except ValueError:
                errors.append("端口必须是数字。" )
                new_port = inbound.get("port")

            if not new_ws_path:
                stream_cur = inbound.get("streamSettings") or {}
                ws_cur = stream_cur.get("wsSettings") or {}
                new_ws_path = ws_cur.get("path", "")

            if errors:
                message = " / ".join(errors)
            else:
                inbound["listen"] = new_listen
                inbound["port"] = new_port

                stream = inbound.get("streamSettings")
                if not isinstance(stream, dict):
                    stream = {}
                inbound["streamSettings"] = stream
                stream.setdefault("network", "ws")
                ws = stream.get("wsSettings")
                if not isinstance(ws, dict):
                    ws = {}
                stream["wsSettings"] = ws
                ws["path"] = new_ws_path

                settings = inbound.get("settings")
                if not isinstance(settings, dict):
                    settings = {}
                inbound["settings"] = settings

                if proto in ("vmess", "vless", "trojan") and new_auth:
                    clients = settings.get("clients")
                    if not isinstance(clients, list) or not clients:
                        clients = [{}]
                    settings["clients"] = clients
                    if not isinstance(clients[0], dict):
                        clients[0] = {}
                    c0 = clients[0]
                    if proto in ("vmess", "vless"):
                        c0["id"] = new_auth
                        if proto == "vmess":
                            c0.setdefault("alterId", 0)
                        else:
                            c0.setdefault("level", 0)
                    elif proto == "trojan":
                        c0["password"] = new_auth

                cfg["inbounds"] = inbounds
                save_config(cfg)
                edited_info = {
                    "tag": edit_tag,
                    "protocol": proto,
                    "listen": new_listen,
                    "port": new_port,
                    "ws_path": new_ws_path,
                    "auth": new_auth or "(未修改)",
                }
                message = "✅ 已更新入站配置，并写入 config.json。"

    return message, created_info, edited_info
