# V2Panel – 轻量级 V2Ray 配置管理面板

> 本 README 是为 **下一个接手本项目的 GPT / 开发者** 准备的说明文档，  
> 重点说明当前项目的整体结构、前端改造点、以及需要 **保留与注意** 的逻辑。

---

## 0. 项目概览

V2Panel 是一个基于 Web 的轻量 V2Ray 管理面板，主要功能：

- 读取并解析 `config.json`（典型路径：`/usr/local/bin/v2ray/config.json`）
- 展示 **入站 (inbounds)** / **出站 (outbounds)** 列表
- 管理 **路由规则**：`inboundTag → outboundTag`
- 支持界面上：
  - 新增入站
  - 编辑入站（带自动填充）
  - 安装 / 重启 V2Ray
  - 修改面板登录账号 / 密码（前端弹窗 + 后端接口）

前端采用 **极简浅色风格**，尽量在不改变后端逻辑的前提下，让 UI 更清爽、结构更清晰。

---

## 1. 主要技术栈与运行环境

- 后端：Python（推测为 Flask 或相近框架）
- 模板引擎：Jinja2（`{{ }}`、`{% %}` 语法）
- 前端：原生 HTML + CSS + JavaScript（无前端框架）
- 典型入口文件：
  - `app.py`（或同等后端主文件）
  - 模板：`templates/index.html`
  - 静态资源（如有）：`static/`

> ⚠️ 注意：本 README 不绑定具体的部署方式（systemd、Docker 等），  
> 只关注代码结构和逻辑约定。

---

## 2. 路由与后端逻辑约定

### 2.1 面板前缀 `panel_prefix`

模板中多处使用：

```jinja2
{{ panel_prefix }}
约定：

panel_prefix 用于支持面板挂载在某个子路径下，例如 /panel。

若挂载在根路径 /，则 panel_prefix 可为空字符串 ""。

示例链接使用：

html
复制代码
<form method="post" action="{{ panel_prefix }}/install_v2ray">
<a href="{{ panel_prefix }}/logout" class="link-ghost">Logout</a>
<form method="post" action="{{ panel_prefix }}/change_account">
<a href="{{ (panel_prefix or '') ~ '/' }}" class="copyright-bar">
请在后端渲染模板时，务必传入 panel_prefix 变量。

2.2 模板期望的后端变量
index.html 模板中用到的变量包括（但不限于）：

全局提示 / 状态

message：操作成功 / 失败等信息字符串，可为空。

config_missing：布尔值，是否未检测到 V2Ray 配置文件。

install_output：安装脚本输出的文本。

入站 / 出站数据

inbound_rows：列表，每项为一个 dict，字段包括：

tag

protocol

listen

port

network

ws_path

outbound_rows：列表，每项为一个 dict，字段包括：

tag

protocol

address

port

路由相关

inbound_tags_all：所有入站 tag 的列表。

inbound_proto_map：{tag: protocol} 的映射。

outbound_tags：可选的 outbound tag 列表。

editable_route_map：{inboundTag: outboundTag} 现有的路由映射。

入站编辑自动填充

edit_inbound_defaults：

一个类似 {tag: {listen, port, ws_path, auth}} 的 dict。

会在模板中通过 tojson 注入到 JS 里，作为自动填充的数据源。

2.3 后端接口行为约定
以下为前端已经依赖的行为约定，请保持兼容：

2.3.1 安装 / 重启 V2Ray
html
复制代码
<form method="post" action="{{ panel_prefix }}/install_v2ray">
  <button type="submit" class="btn-secondary">重启 / 安装 v2ray</button>
</form>
后端路由：

POST {{ panel_prefix }}/install_v2ray

预期行为：

执行安装 / 重启脚本。

将脚本的标准输出收集为 install_output。

渲染同一个模板，将 install_output 传入。

2.3.2 修改路由映射（inboundTag → outboundTag）
表单结构：

html
复制代码
<form method="post">
  <input type="hidden" name="action" value="update_routes">
  <!-- 每行 route_{{ tag }} 对应一个下拉框 -->
  <select name="route_{{ tag }}">
    <option value="NONE">（不为此入口设置路由规则）</option>
    <!-- outbound_tags -->
  </select>
</form>
约定：

action == "update_routes" 时：

遍历 inbound_tags_all，读取表单字段 route_<tag>。

若值为 NONE，表示对这个入口不设置路由规则。

否则，将该入口对应的路由 outboundTag 写回 config.json。

2.3.3 新增入站
表单结构：

html
复制代码
<form method="post">
  <input type="hidden" name="action" value="add_inbound">
  <input name="protocol">
  <input name="listen">
  <input name="port">
  <input name="tag">
  <input name="ws_path">
  <input name="auth">
</form>
后端约定：

从表单读取参数：

protocol：必填（vmess / vless / trojan）。

listen：可选，默认 127.0.0.1。

port：必填。

tag：可选，留空则自动生成（如 vmess-55555）。

ws_path：可选，留空则使用 /tag。

auth：可选，空则由后端自动生成（UUID 或密码）。

将新的 inbound 条目追加进 config.json 并保存。

2.3.4 编辑入站（带自动填充）
表单结构：

html
复制代码
<form method="post">
  <input type="hidden" name="action" value="edit_inbound">
  <select name="edit_tag">...</select>
  <input name="edit_listen">
  <input name="edit_port">
  <input name="edit_ws_path">
  <input name="edit_auth">
</form>
后端约定：

action == "edit_inbound" 时：

根据 edit_tag 找到对应 inbound。

如果对应字段 非空，则修改：

edit_listen → listen

edit_port → port

edit_ws_path → ws_path

edit_auth → 用户 UUID / 密码等

为空字符串就表示“不修改该字段”。

前端自动填充依赖 JS（见后文）。

2.3.5 修改面板账号 / 密码
前端有一个弹窗（modal），提交到：

html
复制代码
<form method="post" action="{{ panel_prefix }}/change_account">
  <input name="current_username">
  <input type="password" name="current_password">
  <input name="new_username">
  <input type="password" name="new_password">
</form>
后端约定：

验证当前账号 / 密码是否正确。

成功后：

更新面板登录凭据（例如写入配置文件、数据库等）。

通常应将当前会话登出或失效，让用户重新登录。

失败时：

设置 message 为错误提示，重新渲染模板。

3. 前端模板 index.html 说明
这一节专门给以后继续修改界面的人看（尤其是 GPT）。

3.1 结构概览
index.html 的大结构：

<header>：页面标题 + 顶部按钮（重启/安装、修改账号密码、Logout）

顶部黄色提示条：提醒保存并重启生效

可选绿色 message 提示

可选「未检测到 V2Ray 配置」卡片

双列布局：

左：入站总览

右：出站总览

路由编辑卡片：inboundTag → outboundTag

双列布局：

左：新增入站

右：编辑入站（带自动填充）

可选安装脚本输出卡片

三段式 Footer（改造重点）

修改账号密码弹窗（modal）

3.2 入站自动填充逻辑（JS 部分）
在页面底部有：

html
复制代码
<script>
const V2PANEL_EDIT_INBOUND_DEFAULTS = {{ edit_inbound_defaults | tojson | safe }};

function v2panelFillEditInboundForm() {
  var select = document.querySelector('select[name="edit_tag"]');
  if (!select) return;

  var tag = select.value;
  var data = V2PANEL_EDIT_INBOUND_DEFAULTS[tag] || {};

  var listenInput = document.querySelector('input[name="edit_listen"]');
  var portInput   = document.querySelector('input[name="edit_port"]');
  var wsInput     = document.querySelector('input[name="edit_ws_path"]');
  var authInput   = document.querySelector('input[name="edit_auth"]');

  if (listenInput) listenInput.value = data.listen || "";
  if (portInput)   portInput.value   =
    data.port !== undefined && data.port !== null ? String(data.port) : "";
  if (wsInput)     wsInput.value     = data.ws_path || "";
  if (authInput)   authInput.value   = data.auth || "";
}

document.addEventListener("DOMContentLoaded", function () {
  var select = document.querySelector('select[name="edit_tag"]');
  if (select) {
    select.addEventListener("change", v2panelFillEditInboundForm);
    // 初次载入时，用当前选中的 tag 自动填充一遍
    v2panelFillEditInboundForm();
  }

  // ... 账号弹窗逻辑 ...
});
</script>
关键点：

edit_inbound_defaults 的结构必须与 JS 期望一致：

示例结构（Python 侧）：

python
复制代码
edit_inbound_defaults = {
    "vmess-55555": {
        "listen": "127.0.0.1",
        "port": 55555,
        "ws_path": "/vmess-55555",
        "auth": "uuid-xxxx"
    },
    # ...
}
tojson | safe 把它作为 JS 对象字面量注入。

不要 手动在模板中用字符串拼接 JSON，以免产生语法错误（之前的 Invalid or unexpected token 就是类似问题）。

3.3 修改账号密码弹窗（modal）
HTML 结构：

触发按钮（在 header 的右上角）：

html
复制代码
<button type="button" class="btn-ghost-dark" id="open-account-modal-btn">
  修改账号密码
</button>
弹窗本体：

html
复制代码
<div class="modal-backdrop" id="account-modal-backdrop">
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="account-modal-title">
    <div class="modal-header">
      <h2 id="account-modal-title">修改面板账号密码</h2>
      <button type="button" class="modal-close" id="account-modal-close-btn" aria-label="关闭">
        ×
      </button>
    </div>
    <form method="post" action="{{ panel_prefix }}/change_account">
      <!-- 四个输入框 -->
    </form>
  </div>
</div>
JS 控制逻辑：

js
复制代码
var openBtn    = document.getElementById("open-account-modal-btn");
var backdrop   = document.getElementById("account-modal-backdrop");
var closeBtn   = document.getElementById("account-modal-close-btn");

function openModal() {
  if (!backdrop) return;
  backdrop.classList.add("is-open");
}

function closeModal() {
  if (!backdrop) return;
  backdrop.classList.remove("is-open");
}

if (openBtn && backdrop) {
  openBtn.addEventListener("click", openModal);

  if (closeBtn) {
    closeBtn.addEventListener("click", closeModal);
  }

  backdrop.addEventListener("click", function (e) {
    if (e.target === backdrop) {
      closeModal();
    }
  });

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
      closeModal();
    }
  });
}
样式：

背景遮罩：.modal-backdrop + .modal-backdrop.is-open 控制显示/隐藏。

Modal 卡片：.modal，带圆角、阴影，居中显示。

4. Footer 三段式说明（此次前端改造重点）
Footer 被设计成“三段式”：

第一段：Powered by Credits

第二段：主品牌区（深色块）

第三段：底部版权条

4.1 第一段 Powered by – 胶囊式合作方 Logo
HTML：

html
复制代码
<div class="credits-strip">
  <div class="credits-row">
    <span class="credits-label">Powered by</span>
    <div class="credits-items">
      <a
        href="https://openai.com"
        target="_blank"
        rel="noopener noreferrer"
        class="credit-pill"
        data-label="ChatGPT AI Assistance"
        aria-label="ChatGPT AI Assistance"
      >
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/OpenAI_Logo.svg/330px-OpenAI_Logo.svg.png" alt="OpenAI">
      </a>

      <a
        href="https://www.cloudflare.com"
        target="_blank"
        rel="noopener noreferrer"
        class="credit-pill"
        data-label="Cloudflare Network"
        aria-label="Cloudflare Network"
      >
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/4b/Cloudflare_Logo.svg/330px-Cloudflare_Logo.svg.png" alt="Cloudflare">
      </a>

      <a
        href="https://aws.amazon.com"
        target="_blank"
        rel="noopener noreferrer"
        class="credit-pill"
        data-label="AWS Cloud"
        aria-label="AWS Cloud"
      >
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Amazon_Web_Services_Logo.svg/330px-Amazon_Web_Services_Logo.svg.png" alt="AWS">
      </a>
    </div>
  </div>
</div>
样式要点（简化版）：

css
复制代码
.credits-strip {
  background: #f9fafb;
  border-radius: 12px;
  border: 1px solid #e5e7eb;
  padding: 10px 16px;
  margin-bottom: 10px;
}

.credits-row {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

.credits-label {
  font-size: 12px;
  color: #6b7280;
}

.credits-items {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

/* 胶囊 */
.credit-pill {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 4px 14px;
  min-height: 32px;
  border-radius: 999px;
  background: #ffffff;
  color: #111827;
  text-decoration: none;
  cursor: pointer;
  border: 1px solid #e5e7eb;
  box-shadow: 0 4px 10px rgba(15,23,42,0.18);
  transition: transform 0.12s ease, box-shadow 0.12s ease, background 0.12s ease, border-color 0.12s ease;
  overflow: hidden;
}

.credit-pill:hover {
  transform: translateY(-1px);
  box-shadow: 0 6px 14px rgba(15,23,42,0.28);
  border-color: #cbd5e1;
  background: #ffffff;
}

.credit-pill img {
  height: 18px;
  width: auto;
  display: block;
}

/* 悬停提示文字 */
.credit-pill::after {
  content: attr(data-label);
  position: absolute;
  white-space: nowrap;
  bottom: -26px;
  left: 50%;
  transform: translateX(-50%);
  background: #111827;
  color: #f9fafb;
  padding: 3px 6px;
  border-radius: 999px;
  font-size: 10px;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.12s ease, transform 0.12s ease;
  transform-origin: top center;
}

.credit-pill:hover::after {
  opacity: 1;
  transform: translateX(-50%) translateY(1px);
}
设计思路：

Logo 不再强行塞进圆点，采用胶囊容器 + 等比缩放Logo。

使用 公网 PNG 替代本地文件，避免静态资源路径问题导致 500。

Tooltip 提示保留，内容由 data-label 控制。

以后如需换成本地 static 文件，只需要把 src="..." 换成对应 url_for('static', filename='xx.png') 即可，但要注意模板语法不能写错。

4.2 第二段：主 Footer 品牌区
HTML：

html
复制代码
<div class="main-footer">
  <div class="main-footer-left">
    <div class="brand-mark">V2</div>
    <div>
      <div class="brand-text-main">V2Panel</div>
      <div class="brand-text-sub">简洁强大的 V2Ray 配置管理面板</div>
    </div>
  </div>
  <div class="main-footer-right">
    <a href="#" class="main-footer-link">About</a>
    <a href="#" class="main-footer-link">GitHub</a>
    <a href="#" class="main-footer-link">Docs</a>
    <a href="#" class="main-footer-link">Support</a>
  </div>
</div>
深色背景，与页面主体浅色形成对比。

右侧链接目前是占位符，可换成真实的项目链接。

4.3 第三段：版权条
HTML：

html
复制代码
<a
  href="{{ (panel_prefix or '') ~ '/' }}"
  class="copyright-bar"
  title="返回面板首页"
>
  © 2025 V2Panel · All rights reserved
</a>
样式：

黑底白字、全宽圆角条 + 明显投影。

Hover 时有轻微放大 + 阴影变强，重点强调“品牌 & 年份”。

5. 未来 GPT / 开发者修改指南
给下一个接手的你几条建议：

前端只动样式，不要随便改表单字段名 / action

因为后端已经依赖了这些字段名，如 action、edit_tag、route_<tag> 等。

改 JS 时记得 V2PANEL_EDIT_INBOUND_DEFAULTS 是从后端注入的 JSON

不要破坏 tojson | safe，也不要再手写 JSON 字符串拼接。

保留 panel_prefix 逻辑

所有后端提交 / 跳转都用 {{ panel_prefix }} 或 {{ (panel_prefix or '') ~ '/' }}。

如要更换 Logo 来源

可以切回 static/ 本地文件，但要确保：

静态目录配置正确（Flask 默认 static）。

url_for('static', filename='...') 写对。

保持 README 更新

如果再做大改，比如：多页面拆分、引入前端框架（React/Vue 等），
记得在此基础上补充变更说明。

6. 致谢 & 版权说明
V2Ray 本体及其 Logo / 名称归其作者及相关社区所有。

OpenAI、Cloudflare、AWS 的名称与 Logo 都是各自公司的商标或注册商标。

本项目使用的外链 Logo 仅为界面装饰与归因展示，请遵守各品牌的使用规范。

如需继续改造 UI，可以在此 README 的基础上添加更多截图、交互说明、以及后端的数据结构文档，方便下一位维护者快速上手。