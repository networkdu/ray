"""Helpers for working with V2Ray inbounds/outbounds.

This module mainly provides:

- build_inbound_rows:   build lightweight rows for the inbounds overview table.
- build_outbound_rows:  build rows + tags for the outbounds overview table.
- extract_inbound_auth: extract UUID/password from inbound settings.
- build_edit_inbound_defaults: build defaults used by the “编辑入站” form.
"""

from typing import Any, Dict, List, Tuple


def build_inbound_rows(inbounds: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Build a list of lightweight rows for the inbounds overview table.

    Each row is a dict with keys:
      - tag
      - protocol
      - listen
      - port
      - network
      - ws_path
    """
    rows: List[Dict[str, Any]] = []
    for ib in inbounds or []:
        if not isinstance(ib, dict):
            continue

        protocol = ib.get("protocol", "")
        tag = ib.get("tag", "")
        port = ib.get("port", "")
        listen = ib.get("listen", "")

        stream = ib.get("streamSettings") or {}
        if not isinstance(stream, dict):
            stream = {}
        network = stream.get("network", "")

        ws = stream.get("wsSettings") or {}
        if not isinstance(ws, dict):
            ws = {}
        ws_path = ws.get("path", "")

        rows.append(
            {
                "tag": tag,
                "protocol": protocol,
                "listen": listen,
                "port": port,
                "network": network,
                "ws_path": ws_path,
            }
        )
    return rows


def build_outbound_rows(
    outbounds: List[Dict[str, Any]]
) -> Tuple[List[Dict[str, Any]], List[str]]:
    """Build rows for the outbounds overview table.

    Returns (rows, outbound_tags).

    Each row has:
      - tag
      - protocol
      - address
      - port
    """
    outbound_rows: List[Dict[str, Any]] = []
    outbound_tags: List[str] = []

    for ob in outbounds or []:
        if not isinstance(ob, dict):
            continue

        protocol = ob.get("protocol", "")
        tag = ob.get("tag", "")

        settings = ob.get("settings") or {}
        if not isinstance(settings, dict):
            settings = {}

        address = ""
        port = ""

        # Common V2Ray outbound formats
        vnext = settings.get("vnext") or []
        servers = settings.get("servers") or []

        target = None
        if isinstance(vnext, list) and vnext:
            target = vnext[0]
        elif isinstance(servers, list) and servers:
            target = servers[0]

        if isinstance(target, dict):
            address = target.get("address", "") or ""
            port = target.get("port", "") or ""

        outbound_rows.append(
            {
                "tag": tag,
                "protocol": protocol,
                "address": address,
                "port": port,
            }
        )
        if tag:
            outbound_tags.append(tag)

    return outbound_rows, outbound_tags


def extract_inbound_auth(inbound: Dict[str, Any]) -> str:
    """Extract auth info from inbound.

    - vmess/vless: uuid (clients[0].id)
    - trojan: password (clients[0].password)

    Returns empty string if not found.
    """
    if not isinstance(inbound, dict):
        return ""

    proto = (inbound.get("protocol") or "").lower()
    settings = inbound.get("settings") or {}
    if not isinstance(settings, dict):
        settings = {}

    clients = settings.get("clients") or []
    if not isinstance(clients, list) or not clients:
        return ""
    c0 = clients[0]
    if not isinstance(c0, dict):
        return ""

    if proto in ("vmess", "vless"):
        return c0.get("id", "") or ""
    if proto == "trojan":
        return c0.get("password", "") or ""

    return ""


def build_edit_inbound_defaults(
    inbounds: List[Dict[str, Any]]
) -> Dict[str, Dict[str, Any]]:
    """Build defaults used to pre-fill the 'Edit inbound' form.

    Returns a mapping:

        {
          "tag1": {
             "listen": "127.0.0.1",
             "port": 12345,
             "ws_path": "/websocket",
             "auth": "uuid-or-password",
          },
          ...
        }
    """
    defaults: Dict[str, Dict[str, Any]] = {}

    for ib in inbounds or []:
        if not isinstance(ib, dict):
            continue

        tag = ib.get("tag") or ""
        if not tag:
            continue

        listen = ib.get("listen", "") or ""
        port = ib.get("port", "") or ""

        stream = ib.get("streamSettings") or {}
        if not isinstance(stream, dict):
            stream = {}
        ws = stream.get("wsSettings") or {}
        if not isinstance(ws, dict):
            ws = {}
        ws_path = ws.get("path", "") or ""

        auth = extract_inbound_auth(ib) or ""

        defaults[tag] = {
            "listen": listen,
            "port": port,
            "ws_path": ws_path,
            "auth": auth,
        }

    return defaults

