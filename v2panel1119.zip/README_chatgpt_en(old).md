# README_chatgpt_en.md
> Handoff notes for the next ChatGPT session (split modules + edit-form prefill)

Please **read this file fully** before changing any code.  
The goal is to evolve the panel in **small and safe** steps, not to rewrite everything.

---

## 1. What is this project?

- A tiny **V2Ray configuration management panel**.
- Tech stack: **Flask (backend) + plain HTML/CSS + a bit of vanilla JS (frontend)**.
- Single responsibility: **safely edit `/usr/local/bin/v2ray/config.json`**.

Key features implemented:

1. Display current config:
   - inbound list (tag / protocol / listen / port / ws path);
   - outbound list (tag / protocol / address / port).
2. Manage one type of “simple routing” rule:
   - `type = "field"` rules with only `inboundTag`/`inboundTags` + `outboundTag`.
3. Add inbound entries:
   - Supports `vmess / vless / trojan`, all using WebSocket (`network = "ws"`).
4. Edit existing inbound entries:
   - Can change listen / port / ws path / auth (UUID or password);
   - **The edit form is automatically pre‑filled with current values (already implemented).**
5. Restart v2ray with one click:
   - Runs `systemctl restart v2ray`.

---

## 2. Current code layout (already split into modules)

Top-level structure:

- `app.py` – Flask entrypoint & web layer
- `v2panel_core.py` – very thin “facade”, exporting only two entrypoints
- `v2panel_config.py` – config file IO + tag filling for inbounds
- `v2panel_routing.py` – parsing simple inboundTag → outboundTag routing rules
- `v2panel_inbounds.py` – inbound/outbound view models + auth extraction
- `v2panel_actions.py` – all POST actions (writes to config)
- `v2panel_context.py` – builds the template context (including edit-form defaults)
- `templates/`
  - `index.html` – main panel page (includes JS for edit-form prefill)
  - `login.html` – login page
- `README_chatgpt_zh.md` / `README_chatgpt_en.md` – this handoff in Chinese/English

### 2.1 `app.py` (do not break the interface)

- Responsibilities:
  - login / logout;
  - URL prefix via `PANEL_PREFIX` (e.g. `/panel`);
  - routes: `/login`, `/`, `/index`.
- It imports panel logic via:

  ```python
  from v2panel_core import handle_post_action, build_panel_context
  ```

- Usage:
  - GET: `build_panel_context(...)` → render `index.html`;
  - POST: `handle_post_action(request.form)` → mutate config, rebuild context.

> **Do not change the names or return shapes** of these two functions unless you also update `app.py` accordingly.

### 2.2 `v2panel_core.py` (thin facade)

```python
from v2panel_actions import handle_post_action
from v2panel_context import build_panel_context

__all__ = ["handle_post_action", "build_panel_context"]
```

- No business logic here; it only wires together the split modules.
- Future features should generally be added via new modules and then re‑exported here,
  keeping `app.py` stable.

### 2.3 `v2panel_config.py`

- Contains:

  - `CONFIG_PATH = Path("/usr/local/bin/v2ray/config.json")` (do **not** casually change this).
  - `load_config()`:
    - uses `json5` to read the V2Ray config with comments.
  - `save_config(cfg)`:
    - backs up the original file to `config.json.bak`;
    - then writes a new JSON file (no comments).
  - `ensure_inbound_tags(cfg)`:
    - makes sure every inbound has a `tag`:
      - if `port` exists: `"{protocol}-{port}"`;
      - otherwise: `"{protocol}-auto-{index}"`;
    - returns `(inbounds, inbound_tag_to_proto)`.

> **All writes to `config.json` must go through `save_config()`.**

### 2.4 `v2panel_routing.py`

- `parse_simple_routing(cfg)`:

  - looks at `cfg["routing"]["rules"]` and splits them into:
    - `editable_route_map`:
      - rules with `type = "field"` and only `inboundTag(s)` + `outboundTag` keys;
    - `non_editable_rules`:
      - everything else (domain/ip/port, etc.), kept as‑is.
  - returns `(routing_obj, editable_route_map, non_editable_rules)`.

> If you extend routing behavior in the future, keep this “simple editable + complex untouched” design.

### 2.5 `v2panel_inbounds.py`

- `build_inbound_rows(inbounds)`:
  - builds table rows: `tag / protocol / listen / port / network / ws_path`.
- `build_outbound_rows(outbounds)`:
  - builds outbound table rows + a list of `outbound_tags`.
- `extract_inbound_auth(inbound)`:
  - extracts auth info:
    - vmess/vless: `settings.clients[0].id`;
    - trojan: `settings.clients[0].password`.
  - returns `""` if not present.

> The default “auth” displayed in the edit form comes from here.  
> If you change the config schema, update this accordingly.

### 2.6 `v2panel_actions.py`

- Owns all write operations:

  - `restart_v2ray()`:
    - runs `systemctl restart v2ray` and returns a localized message string.
  - `handle_post_action(form)`:
    - supports four actions:
      - `restart` – restart v2ray;
      - `update_routes` – update “simple routing”;
      - `add_inbound` – add vmess/vless/trojan ws inbounds;
      - `edit_inbound` – edit an existing inbound’s core fields and optionally auth.

- All writes flow through `save_config(cfg)` and keep the `.bak` backup.

When adding an inbound, defaults are:

- `listen` defaults to `127.0.0.1`;
- `tag` defaults to `"{protocol}-{port}"`;
- `ws_path` defaults to `"/" + tag`;
- `auth`:
  - vmess/vless: auto-generated UUID if empty;
  - trojan: auto-generated random password if empty.

### 2.7 `v2panel_context.py`

- `build_panel_context(...)`:

  - reads the latest config via `load_config`;
  - calls:
    - `ensure_inbound_tags` / `parse_simple_routing`;
    - `build_inbound_rows` / `build_outbound_rows`;
    - `extract_inbound_auth`.

- It builds a context dict with:

  - `inbound_rows` / `outbound_rows`;
  - `inbound_tags_all` / `outbound_tags`;
  - `editable_route_map` / `inbound_proto_map`;
  - **`edit_inbound_defaults`** – default values for the edit form;
  - `message` / `created_info` / `edited_info` / `panel_prefix`.

The structure of `edit_inbound_defaults` is:

```python
{
  "<tag>": {
    "listen": "...",
    "port": "...",   # string
    "ws_path": "...",
    "auth": "...",   # UUID or password
  },
  ...
}
```

This is passed to the template and serialized to a JS object.

---

## 3. Edit-inbound form auto-prefill (already implemented)

**The user explicitly requested this; do not remove or silently break it.**

### 3.1 Backend: `edit_inbound_defaults`

In `v2panel_context.build_panel_context` we:

- iterate over all inbounds;
- for each tag we collect:
  - `listen` from `ib["listen"]`;
  - `port` (converted to string);
  - `ws_path` from `ib["streamSettings"]["wsSettings"]["path"]`;
  - `auth` from `extract_inbound_auth(ib)`;
- store this in `edit_inbound_defaults[tag]` and pass it to the template.

### 3.2 Frontend: JS in `templates/index.html`

There is a script block before `</body>` that looks like:

```html
<script>
    const V2PANEL_EDIT_INBOUND_DEFAULTS = {{ edit_inbound_defaults | tojson | safe }};

    function v2panelFillEditInboundForm() {
        var select = document.querySelector('select[name="edit_tag"]');
        if (!select) return;
        var data = V2PANEL_EDIT_INBOUND_DEFAULTS[select.value] || {};

        var listenInput = document.querySelector('input[name="edit_listen"]');
        var portInput = document.querySelector('input[name="edit_port"]');
        var wsInput = document.querySelector('input[name="edit_ws_path"]');
        var authInput = document.querySelector('input[name="edit_auth"]');

        if (listenInput) listenInput.value = data.listen || "";
        if (portInput) portInput.value = data.port || "";
        if (wsInput) wsInput.value = data.ws_path || "";
        if (authInput) authInput.value = data.auth || "";
    }

    document.addEventListener('DOMContentLoaded', function () {
        var select = document.querySelector('select[name="edit_tag"]');
        if (!select) return;
        select.addEventListener('change', v2panelFillEditInboundForm);
        v2panelFillEditInboundForm(); // initial fill
    });
</script>
```

Behavior:

- On initial page load:
  - the first tag in the dropdown is used to prefill the form.
- When the user selects a different tag:
  - the four inputs are updated from the corresponding values in `edit_inbound_defaults`.

> If you change field names or form structure later,
> update both `build_panel_context` and this JS snippet accordingly.

---

## 4. Login & security assumptions

- Single-user admin panel; credentials come from env vars:
  - `V2PANEL_USER` / `V2PANEL_PASS`.
- Flask `secret_key` comes from `V2PANEL_SECRET` (default is weak; must be changed in production).

Typical deployment assumptions:

- Panel is either:
  - on an internal network; or
  - behind Nginx with extra Basic Auth / IP restrictions.

There is currently **no CSRF protection**.  
If you add CSRF, prefer a central mechanism in `app.py` (e.g. Flask-WTF, custom decorator),
not scattered per-view token checks.

> Unless the user explicitly asks, do not invent a new auth scheme,
> and do not store passwords or secrets inside `config.json`.

---

## 5. Constraints for write operations (important)

1. All writes to `config.json` must:
   - go through `save_config(cfg)`;
   - keep the “backup to `config.json.bak` first” behavior.

2. Routing management boundary:
   - Only manage **simple inboundTag routes**:
     - `type = "field"`;
     - keys limited to `inboundTag`/`inboundTags` + `outboundTag`.
   - All complex rules (domain/ip/port, etc.) must remain untouched.

3. Restart behavior:
   - Always restart via `systemctl restart v2ray`.
   - If you add features like `status` or “test config”, add them alongside this, not instead of it.

4. UI style:
   - Dark theme, gradient background, light CSS; avoid heavy frontend frameworks (React/Vue/Tailwind).
   - Small, focused JS for UX improvements is fine; keep it simple and readable.

---

## 6. Safe ways to extend the panel

Some examples for future work:

- Add a “Copy node URL” button per inbound:
  - backend builds vmess/vless/trojan URIs from config + env vars;
  - frontend copies to clipboard via `navigator.clipboard.writeText`.
- Add a “Test config” button:
  - runs `v2ray -test -config /usr/local/bin/v2ray/config.json` and shows the result.
- Add a collapsible section that displays the raw `config.json` as read‑only text.

In all cases, aim for **incremental, non‑destructive** changes.

---

## 7. TL;DR for future you

- Entry points remain `v2panel_core.handle_post_action` / `build_panel_context`;
- Every write to the config goes through `save_config()` and keeps the `.bak` backup;
- Only touch “simple inboundTag routes”; never mangle complex rules;
- The edit‑inbound form auto‑prefill is an important UX feature—don’t regress it;
- Don’t pull in heavy new dependencies; keep the project small and understandable.

When a user request is vague, explain your proposed changes first,
then show the concrete code. That greatly reduces accidental breakage.
