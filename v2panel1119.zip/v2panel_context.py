"""Build template context for the main panel page."""

from typing import Any, Dict, Optional, List

from v2panel_config import load_config, ensure_inbound_tags
from v2panel_routing import parse_simple_routing
from v2panel_inbounds import (
    build_inbound_rows,
    build_outbound_rows,
    extract_inbound_auth,  # 保持 API 兼容，暂时没直接用到
    build_edit_inbound_defaults,
)


def build_panel_context(
    message: Optional[str] = None,
    created_info: Optional[Dict[str, Any]] = None,
    edited_info: Optional[Dict[str, Any]] = None,
    panel_prefix: str = "",
) -> Dict[str, Any]:
    """Build the template context for the main panel page.

    主要做几件事：

    - load_config：读取 V2Ray config
    - ensure_inbound_tags：确保每个 inbound 都有 tag，并返回 tag -> protocol 映射
    - parse_simple_routing：解析简单的 routing 规则，得到 inboundTag -> outboundTag 的 map
    - build_inbound_rows / build_outbound_rows：构造前端表格显示用的数据
    - build_edit_inbound_defaults：给“编辑入站”表单提供默认值（自动填充）
    """

    cfg = load_config()

    # 1. inbounds + tag → protocol
    inbounds, inbound_tag_to_proto = ensure_inbound_tags(cfg)
    outbounds: List[Dict[str, Any]] = cfg.get("outbounds", []) or []

    # 2. 解析 routing，把简单的 inboundTag → outboundTag 抽出来
    routing, editable_route_map, non_editable_rules = parse_simple_routing(cfg)

    # 3. 入站/出站总览表格
    inbound_rows = build_inbound_rows(inbounds)
    outbound_rows, outbound_tags = build_outbound_rows(outbounds)
    inbound_tags_all = sorted(inbound_tag_to_proto.keys())

    # 4. “编辑入站”表单的默认值（关键：这里会被模板注入到 JS 里）
    edit_inbound_defaults = build_edit_inbound_defaults(inbounds)

    ctx: Dict[str, Any] = {
        "inbound_rows": inbound_rows,
        "outbound_rows": outbound_rows,
        "inbound_tags_all": inbound_tags_all,
        "outbound_tags": outbound_tags,
        "editable_route_map": editable_route_map,
        "inbound_proto_map": inbound_tag_to_proto,
        "edit_inbound_defaults": edit_inbound_defaults,
        "message": message,
        "created_info": created_info,
        "edited_info": edited_info,
        "panel_prefix": panel_prefix,
    }

    # 如果后续你想在模板里调试 routing，也可以把下面两行解开：
    # ctx["routing"] = routing
    # ctx["non_editable_rules"] = non_editable_rules

    return ctx

