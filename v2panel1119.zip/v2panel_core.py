from v2panel_actions import handle_post_action as _handle_post_action
from v2panel_context import build_panel_context as _build_panel_context
from v2panel_config import CONFIG_PATH


def handle_post_action(form):
    """
    包一层，保证在没有 V2Ray 配置文件的时候不会直接报 500，
    而是给用户一个友好的提示。
    """
    # 如果压根没有 config.json，就不要去改它，直接提示安装
    if not CONFIG_PATH.exists():
        message = "当前尚未检测到 V2Ray 配置文件，请先执行一键安装。"
        return message, None, None

    try:
        return _handle_post_action(form)
    except FileNotFoundError:
        # 双保险：万一底层还是因为找不到文件抛异常，这里兜底
        message = "未找到 V2Ray 配置文件，请先执行一键安装。"
        return message, None, None


def build_panel_context(
    message=None,
    created_info=None,
    edited_info=None,
    panel_prefix="",
    install_output=None,
):
    """
    包一层原始 build_panel_context：
    - 如果 config.json 缺失，不再抛异常，而是返回一个空面板 + 提示；
    - 同时注入 config_missing / install_output 供模板使用。
    """
    cfg_missing = False
    try:
        ctx = _build_panel_context(
            message=message,
            created_info=created_info,
            edited_info=edited_info,
            panel_prefix=panel_prefix,
        )
    except FileNotFoundError:
        cfg_missing = True
        ctx = {
            "inbound_rows": [],
            "outbound_rows": [],
            "inbound_tags_all": [],
            "outbound_tags": [],
            "editable_route_map": {},
            "inbound_proto_map": {},
            "edit_inbound_defaults": {},
            "message": message or "未检测到 V2Ray 配置文件，请先执行一键安装。",
            "created_info": created_info,
            "edited_info": edited_info,
            "panel_prefix": panel_prefix,
        }

    # 万一上面没抛异常，但文件依然不存在，也视为缺失
    if not CONFIG_PATH.exists():
        cfg_missing = True

    ctx["config_missing"] = cfg_missing
    ctx["install_output"] = install_output
    return ctx


__all__ = ["handle_post_action", "build_panel_context"]

