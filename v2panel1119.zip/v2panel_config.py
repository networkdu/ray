from pathlib import Path
import shutil
import json5
import json

# Path to the V2Ray config file (keep in sync with original behavior)
CONFIG_PATH = Path("/usr/local/bin/v2ray/config.json")


def load_config():
    """Read V2Ray config (JSONC with comments) into a Python dict."""
    with CONFIG_PATH.open("r", encoding="utf-8") as f:
        return json5.load(f)


def save_config(cfg):
    """Backup the original config and write a new JSON config."""
    backup_path = CONFIG_PATH.with_name(CONFIG_PATH.name + ".bak")
    shutil.copy2(CONFIG_PATH, backup_path)
    with CONFIG_PATH.open("w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def ensure_inbound_tags(cfg):
    """Ensure every inbound has a tag; return (inbounds, tag->protocol)."""
    inbounds = cfg.get("inbounds", []) or []
    inbound_tag_to_proto = {}
    for idx, ib in enumerate(inbounds):
        proto = ib.get("protocol", "inbound")
        tag = ib.get("tag")
        port = ib.get("port")
        if not tag:
            if port:
                tag = f"{proto}-{port}"
            else:
                tag = f"{proto}-auto-{idx}"
            ib["tag"] = tag
        inbound_tag_to_proto[tag] = proto
    cfg["inbounds"] = inbounds
    return inbounds, inbound_tag_to_proto
